public class Listenelement {
    public Ausgabe data;
    public Listenelement next;


}
